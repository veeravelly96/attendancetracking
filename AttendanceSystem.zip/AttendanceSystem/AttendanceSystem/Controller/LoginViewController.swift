//
//  LoginViewController.swift
//  AttendanceSystem
//
//  Created by Ali Sher on 02/09/2022.
//

import UIKit

class LoginViewController: UIViewController {
    
    
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    
    @IBOutlet weak var loginBtn: UIButton!
    
    var userType = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Faculty"
        if userType == "student" {
            
            self.navigationItem.title = "Student"
        }
        
        loginBtn.RoundCorners(radius: 8)
    }
    
    @IBAction func loginBtnClicked(_ sender: Any) {
        
        if userType == "student" {
            
            let VC = self.storyboard?.instantiateViewController(withIdentifier: "StudentCoursesVC") as! StudentCoursesVC
            self.navigationController!.pushViewController(VC, animated: true)
            self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
            
        }else {
            
            let VC = self.storyboard?.instantiateViewController(withIdentifier: "FacultySeasonVC") as! FacultySeasonVC
            self.navigationController!.pushViewController(VC, animated: true)
            self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        }
    }
}
