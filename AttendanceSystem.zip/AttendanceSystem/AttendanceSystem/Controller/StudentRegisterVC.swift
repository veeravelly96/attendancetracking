//
//  StudentRegisterVC.swift
//  AttendanceSystem
//
//  Created by Ali Sher on 02/09/2022.
//

import UIKit

class StudentRegisterVC: UIViewController {

    @IBOutlet weak var registerBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Student"
        registerBtn.RoundCorners(radius: 8)
    }
    
    
    @IBAction func registerBtnClicked(_ sender: Any) {
    }
}
