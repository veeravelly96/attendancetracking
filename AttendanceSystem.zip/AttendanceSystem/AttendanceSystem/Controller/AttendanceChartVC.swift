//
//  AttendanceChartVC.swift
//  AttendanceSystem
//
//  Created by Ali Sher on 09/09/2022.
//

import UIKit
import FLCharts


class AttendanceChartVC: UIViewController {
    
    @IBOutlet var cardView: FLCard!
    
    var userType = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Faculty"
        if userType == "student" {
            
            self.navigationItem.title = "Student"
        }
        
        self.showAttendance()
    }
    
    
    func showAttendance() -> Void {
        
        let data = [FLPiePlotable(value: 68.7, key: Key(key: "On Time", color: FLColor(hex: "008000"))),
                    FLPiePlotable(value: 10.6, key: Key(key: "Late", color: FLColor(hex: "00FF00"))),
                    FLPiePlotable(value: 9.7, key: Key(key: "Absent", color: FLColor(hex: "800000"))),
                    FLPiePlotable(value: 11.0, key: Key(key: "Leave", color: FLColor(hex: "FFFF00")))]
        
        let pieChart = FLPieChart(title: "Pie Chart",
                                  data: data,
                                  border: .full,
                                  formatter: .percent,
                                  animated: true)
        
        cardView.setup(chart: pieChart, style: .rounded)
        cardView.showAverage = true
        cardView.showLegend = true
        cardView.backgroundColor = .clear
        
    }
}
