//
//  GenerateQRVC.swift
//  AttendanceSystem
//
//  Created by Ali Sher on 06/09/2022.
//

import UIKit

class GenerateQRVC: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Faculty"
        let image = generateQRCode(from: "Hacking with Swift is the best iOS coding tutorial I've ever read!")
        
    }
    
    func generateQRCode(from string: String) -> UIImage? {
        let data = string.data(using: String.Encoding.ascii)

        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 3, y: 3)

            if let output = filter.outputImage?.transformed(by: transform) {
                return UIImage(ciImage: output)
            }
        }

        return nil
    }
    
}
