//
//  FacultyCoursesVC.swift
//  AttendanceSystem
//
//  Created by Ali Sher on 02/09/2022.
//

import UIKit

class FacultyCoursesVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var coursesTableView: UITableView!
    
    let courses = ["Java", "OOP", "Math"]
    var selectedIndex = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Faculty"
        self.navigationItem.hidesBackButton = true
        coursesTableView.delegate = self
        coursesTableView.dataSource = self
        coursesTableView.backgroundColor = .clear
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return courses.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "courseCell", for: indexPath) as! CourseTableViewCell
        cell.backgroundColor = .clear
        
        cell.courseLbl.text = courses[indexPath.row]
        cell.imgView.image = UIImage(named: "RadioUnChecked")
        
        if indexPath.row == selectedIndex {
            
            cell.imgView.image = UIImage(named: "RadioChecked")
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectedIndex = indexPath.row
        tableView.reloadData()
        
        let VC = self.storyboard?.instantiateViewController(withIdentifier: "FacultySectionVC") as! FacultySectionVC
        self.navigationController!.pushViewController(VC, animated: true)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
}
