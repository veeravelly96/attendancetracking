//
//  FacultySectionVC.swift
//  AttendanceSystem
//
//  Created by Ali Sher on 02/09/2022.
//

import UIKit

class FacultySectionVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var sectionsTableView: UITableView!
    
    let sections = ["Section A", "Section B", "Section C"]
    var selectedIndex = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Faculty"
        
        sectionsTableView.delegate = self
        sectionsTableView.dataSource = self
        sectionsTableView.backgroundColor = .clear
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return sections.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath) as! SectionTableViewCell
        cell.backgroundColor = .clear
        
        cell.sectionLbl.text = sections[indexPath.row]
        cell.imgView.image = UIImage(named: "RadioUnChecked")
        
        if indexPath.row == selectedIndex {
            
            cell.imgView.image = UIImage(named: "RadioChecked")
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectedIndex = indexPath.row
        tableView.reloadData()
        
        let VC = self.storyboard?.instantiateViewController(withIdentifier: "AttendanceChartVC") as! AttendanceChartVC
        
        VC.userType = "faculty"
        
        self.navigationController!.pushViewController(VC, animated: true)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        
    }
}
