//
//  FacultySeasonVC.swift
//  AttendanceSystem
//
//  Created by Ali Sher on 09/09/2022.
//

import UIKit

class FacultySeasonVC: UIViewController {
    
    @IBOutlet var seasonView: UIView!
    @IBOutlet var seasonBtn: UIButton!
    
    @IBOutlet var seasonsView: UIView!
    
    @IBOutlet var yearView: UIView!
    @IBOutlet var yearBtn: UIButton!
    
    @IBOutlet var dtPicker: UIDatePicker!
    @IBOutlet var dateView: UIView!
    
    @IBOutlet var nextBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        seasonView.RoundCorners(radius: 8)
        yearView.RoundCorners(radius: 8)
        dateView.RoundCorners(radius: 8)
        nextBtn.RoundCorners(radius: 8)
        
        dateView.isHidden = true
        seasonsView.isHidden = true
    }
    
    @IBAction func seasonTapped(_ sender: Any) {
        
        seasonsView.isHidden = false
    }
    
    @IBAction func fallTapped(_ sender: Any) {
        
        seasonsView.isHidden = true
        seasonBtn.setTitle("Fall", for: .normal)
    }
    
    @IBAction func springTapped(_ sender: Any) {
        
        seasonsView.isHidden = true
        seasonBtn.setTitle("Spring", for: .normal)
    }
    
    @IBAction func yearTapped(_ sender: Any) {
        
        dateView.isHidden = false
    }
    
    @IBAction func cancelTapped(_ sender: Any) {
        
        dateView.isHidden = true
    }
    
    @IBAction func doneTapped(_ sender: Any) {
        
        let date = dtPicker.date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy"
        
        yearBtn.setTitle(dateFormatter.string(from: date), for: .normal)
        
        dateView.isHidden = true
    }
    
    @IBAction func nextTapped(_ sender: Any) {
        
        let VC = self.storyboard?.instantiateViewController(withIdentifier: "FacultyCoursesVC") as! FacultyCoursesVC
        self.navigationController!.pushViewController(VC, animated: true)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
}
