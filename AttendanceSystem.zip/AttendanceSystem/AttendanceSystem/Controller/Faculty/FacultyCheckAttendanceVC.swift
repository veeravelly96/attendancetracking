//
//  FacultyCheckAttendanceVC.swift
//  AttendanceSystem
//
//  Created by Ali Sher on 06/09/2022.
//

import UIKit

class FacultyCheckAttendanceVC: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
    }
}
