//
//  ScanLockViewController.swift
//  AttendanceSystem
//
//  Created by Ali Sher on 02/09/2022.
//

import UIKit
import AVFoundation

class ScanQRViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    
    @IBOutlet var titleLbl: UILabel!
    @IBOutlet weak var cameraView: UIView!
    @IBOutlet weak var frameView: UIView!
    @IBOutlet weak var frameImgView: UIImageView!
    @IBOutlet weak var lineView: UIView!
    
    @IBOutlet weak var lineViewTopCons: NSLayoutConstraint!
    
    
    var captureSession: AVCaptureSession!
    var previewLayer: AVCaptureVideoPreviewLayer!
    var lineTimer: Timer?
    var lineY = 5
    var movingDown = true
    
    var isStoped = false
    var isUsingQR = true
    var counter = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Student"
        frameView.isHidden = true
    }
    
    @objc func MoveLine() -> Void {
        
        if movingDown {
            
            lineY += 5
        }else {
            
            lineY -= 5
        }
        
        if lineY == 240 {
            
            movingDown = false
            
        }else if lineY == 5 {
            
            movingDown = true
            
        }
        
        lineViewTopCons.constant = CGFloat(lineY)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        isStoped = false
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        frameView.isHidden = false
        lineTimer = Timer.scheduledTimer(timeInterval: 0.05, target: self, selector: #selector(MoveLine), userInfo: nil, repeats: true)
        InitializeCamera()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        lineTimer?.invalidate()
    }
    
    
    //MARK: QR Code
    func InitializeCamera() -> Void {
        
        view.backgroundColor = UIColor.black
        captureSession = AVCaptureSession()
        
        guard let videoCaptureDevice = AVCaptureDevice.default(for: .video) else { return }
        let videoInput: AVCaptureDeviceInput
        
        do {
            videoInput = try AVCaptureDeviceInput(device: videoCaptureDevice)
        } catch {
            return
        }
        
        if (captureSession.canAddInput(videoInput)) {
            captureSession.addInput(videoInput)
        } else {
            failed()
            return
        }
        
        let metadataOutput = AVCaptureMetadataOutput()
        if (captureSession.canAddOutput(metadataOutput)) {
            captureSession.addOutput(metadataOutput)
            
            metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            metadataOutput.metadataObjectTypes = [.qr]
            
        } else {
            failed()
            return
        }
        
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.frame = cameraView.layer.bounds
        previewLayer.videoGravity = .resizeAspectFill
        
        let scanRect = CGRect(x: self.view.frame.size.width/2 - 125, y: self.view.frame.size.height/2 - 125, width: 300, height: 300)
        let rectOfInterest = previewLayer.metadataOutputRectConverted(fromLayerRect: scanRect)
        metadataOutput.rectOfInterest = rectOfInterest
        
        
        cameraView.layer.addSublayer(previewLayer)
        cameraView.bringSubviewToFront(frameView)
        cameraView.bringSubviewToFront(titleLbl)
        captureSession.commitConfiguration()
        captureSession.startRunning()
    }
    
    func failed() {
        let ac = UIAlertController(title: "Scanning not supported", message: "Your device does not support scanning a code from an item. Please use a device with a camera.", preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default))
        present(ac, animated: true)
        captureSession = nil
    }
    
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        captureSession.stopRunning()
        
        if !isStoped {
            
            isStoped = true
            if let metadataObject = metadataObjects.first {
                guard let readableObject = metadataObject as? AVMetadataMachineReadableCodeObject else { return }
                guard let stringValue = readableObject.stringValue else { return }
                AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
                found(code: stringValue)
            }
            
        }
        
        dismiss(animated: true)
    }
    
    func found(code: String) {
        print(code)
        
        lineTimer?.invalidate()
        
        //MARK Attendance
    }
}
