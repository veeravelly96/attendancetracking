//
//  InitialViewController.swift
//  AttendanceSystem
//
//  Created by Ali Sher on 02/09/2022.
//

import UIKit

class InitialViewController: UIViewController {
    
    
    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var studentBtn: UIButton!
    @IBOutlet weak var facultyBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        logo.RoundCorners(radius: 8)
        studentBtn.RoundCorners(radius: 8)
        facultyBtn.RoundCorners(radius: 8)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.navigationBar.isHidden = true
    }
    
    @IBAction func studentBtnClicked(_ sender: Any) {
        
        self.moveToView(type: "student")
    }
    
    @IBAction func facultyBtnClicked(_ sender: Any) {
        
        self.moveToView(type: "faculty")
    }
    
    func moveToView(type: String) -> Void {
        
        let VC = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        VC.userType = type
        self.navigationController!.pushViewController(VC, animated: true)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
}
