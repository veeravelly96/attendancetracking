//
//  FacultyRegisterVC.swift
//  AttendanceSystem
//
//  Created by Ali Sher on 02/09/2022.
//

import UIKit

class FacultyRegisterVC: UIViewController {
    
    
    @IBOutlet weak var registerBtnClicked: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Faculty"
        registerBtnClicked.RoundCorners(radius: 8)
    }
    
    @IBAction func registerBtnClicked(_ sender: Any) {
        
        
        
    }
}
